import Events from './components/Events'

import './App.css'

const App = () => <Events />

export default App
