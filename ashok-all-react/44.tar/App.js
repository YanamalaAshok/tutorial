import MemeGenerator from './components/MemeGenerator'

import './App.css'

const App = () => <MemeGenerator />

export default App
