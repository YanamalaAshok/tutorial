import './index.css'

const Footer = () => (
  <div className="footer-container">
    <h1 className="footer-text">Footer</h1>
  </div>
)

export default Footer
