import './index.css'

const Header = () => (
  <div className="header-container">
    <h1 className="header-text">Header</h1>
  </div>
)

export default Header
