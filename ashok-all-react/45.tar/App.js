import GradientGenerator from './components/GradientGenerator'

import './App.css'

const App = () => <GradientGenerator />

export default App
