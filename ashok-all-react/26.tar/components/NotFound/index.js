import './index.css'

const NotFound = () => (
  <div className="not-found-route-container">
    <h1 className="not-found-heading">Page Not Found !!</h1>
  </div>
)

export default NotFound
